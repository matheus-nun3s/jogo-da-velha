package jogo;

import java.util.Random;
import javax.swing.JOptionPane;

public class Jogo {

	public static int contadorJogadas = new Random().nextInt(2);

	public static void main(String[] args) {

		JOptionPane.showMessageDialog(null,
				"   Breves esclarecimentos sobre o jogo:\n\n  1° -> X usa botão direito do mouse\n  2° -> O usa botão esquerdo\n  3° -> Só dá pra finalizar o jogo depois de uma partida\n  4° -> Obrigado por jogar!! Até mais. :)",
				"Oie!", JOptionPane.INFORMATION_MESSAGE);

		new MainFrame();

	}

}
