package jogo;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class TelaAuxiliar {

	static JLabel label = new JLabel("", SwingConstants.CENTER);

	TelaAuxiliar() {
		label.setForeground(Color.BLACK);
		label.setFont(new Font("Curial", Font.PLAIN, 15));

	}

	static void atualizarTexto() {
		label.setText(obterTexto());
	}

	static void atualizarTexto(String texto) {
		label.setText(texto);
	}

	static String obterTexto() {
		if (Tabuleiro.temGanhador()) {
			return "          " + Tabuleiro.getGanhador() + " é o vencedor! :)\n";
		} else if (Tabuleiro.tabuleiroPreenchido()) {
			label.setText("Ops...Deu velha, tabuleiro preenchido! :(");
		}
		return Jogo.contadorJogadas % 2 == 0 ? "Vez do X!" : "Vez do O!";

	}

}
