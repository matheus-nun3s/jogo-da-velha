package jogo;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;

public class Tabuleiro {

	static List<BotaoTabuleiro> tabuleiro = new ArrayList<>(9);
	final static String O = "O";
	final static String X = "X";
	static boolean camposDesabilitados = false;
	private static String winner = null;
	private static int[] jogadaVencedora;

	static boolean temGanhador() {
		if (tabuleiro.get(0).getText().equals(O) && tabuleiro.get(1).getText().equals(O)
				&& tabuleiro.get(2).getText().equals(O)) {
			jogadaVencedora = new int[] { 0, 1, 2 };
			winner = O;
			return true;
		} else if (tabuleiro.get(3).getText().equals(O) && tabuleiro.get(4).getText().equals(O)
				&& tabuleiro.get(5).getText().equals(O)) {
			jogadaVencedora = new int[] { 3, 4, 5 };
			winner = O;

			return true;
		} else if (tabuleiro.get(6).getText().equals(O) && tabuleiro.get(7).getText().equals(O)
				&& tabuleiro.get(8).getText().equals(O)) {
			jogadaVencedora = new int[] { 6, 7, 8 };
			winner = O;
			return true;
		} else if (tabuleiro.get(0).getText().equals(O) && tabuleiro.get(3).getText().equals(O)
				&& tabuleiro.get(6).getText().equals(O)) {
			jogadaVencedora = new int[] { 0, 3, 6 };
			winner = O;
			return true;
		} else if (tabuleiro.get(1).getText().equals(O) && tabuleiro.get(4).getText().equals(O)
				&& tabuleiro.get(7).getText().equals(O)) {
			jogadaVencedora = new int[] { 1, 4, 7 };
			winner = O;
			return true;
		} else if (tabuleiro.get(2).getText().equals(O) && tabuleiro.get(5).getText().equals(O)
				&& tabuleiro.get(8).getText().equals(O)) {
			jogadaVencedora = new int[] { 2, 5, 8 };
			winner = O;
			return true;
		} else if (tabuleiro.get(0).getText().equals(O) && tabuleiro.get(4).getText().equals(O)
				&& tabuleiro.get(8).getText().equals(O)) {
			jogadaVencedora = new int[] { 0, 4, 8 };
			winner = O;
			return true;
		} else if (tabuleiro.get(2).getText().equals(O) && tabuleiro.get(4).getText().equals(O)
				&& tabuleiro.get(6).getText().equals(O)) {
			jogadaVencedora = new int[] { 2, 4, 6 };
			winner = O;
			return true;
		} else if (tabuleiro.get(0).getText().equals(X) && tabuleiro.get(1).getText().equals(X)
				&& tabuleiro.get(2).getText().equals(X)) {
			jogadaVencedora = new int[] { 0, 1, 2 };
			winner = X;
			return true;
		} else if (tabuleiro.get(3).getText().equals(X) && tabuleiro.get(4).getText().equals(X)
				&& tabuleiro.get(5).getText().equals(X)) {
			jogadaVencedora = new int[] { 3, 4, 5 };
			winner = X;
			return true;
		} else if (tabuleiro.get(6).getText().equals(X) && tabuleiro.get(7).getText().equals(X)
				&& tabuleiro.get(8).getText().equals(X)) {
			jogadaVencedora = new int[] { 6, 7, 8 };
			winner = X;
			return true;
		} else if (tabuleiro.get(0).getText().equals(X) && tabuleiro.get(3).getText().equals(X)
				&& tabuleiro.get(6).getText().equals(X)) {
			jogadaVencedora = new int[] { 0, 3, 6 };
			winner = X;
			return true;
		}

		else if (tabuleiro.get(1).getText().equals(X) && tabuleiro.get(4).getText().equals(X)
				&& tabuleiro.get(7).getText().equals(X)) {
			jogadaVencedora = new int[] { 1, 4, 7 };
			winner = X;
			return true;
		} else if (tabuleiro.get(2).getText().equals(X) && tabuleiro.get(5).getText().equals(X)
				&& tabuleiro.get(8).getText().equals(X)) {
			jogadaVencedora = new int[] { 2, 5, 8 };
			winner = X;
			return true;
		} else if (tabuleiro.get(0).getText().equals(X) && tabuleiro.get(4).getText().equals(X)
				&& tabuleiro.get(8).getText().equals(X)) {
			jogadaVencedora = new int[] { 0, 4, 8 };
			winner = X;
			return true;
		} else if (tabuleiro.get(2).getText().equals(X) && tabuleiro.get(4).getText().equals(X)
				&& tabuleiro.get(6).getText().equals(X)) {
			jogadaVencedora = new int[] { 2, 4, 6 };
			winner = X;
			return true;
		}
		return false;
	}

	int[] getJogadaVencedora() {
		return jogadaVencedora;
	}

	void limparJogadaVencedora() {
		jogadaVencedora = null;
	}

	void limparTabuleiro() {
		tabuleiro.forEach(b -> b.setText(""));
	}

	static boolean tabuleiroPreenchido() {
		return tabuleiro.stream().noneMatch(b -> b.getText().equals(""));
	}

	static void animacaoTabuleiroPreenchido() {
		tabuleiro.forEach(b -> b.setText("VELHA!"));
		tabuleiro.forEach(b -> b.setFont(new Font("Arial", Font.TYPE1_FONT, 15)));
		for (int i = 0; i < 9; i++) {
			if (i % 2 == 0) {
				tabuleiro.get(i).setBackground(Color.CYAN);
			} else {
				tabuleiro.get(i).setBackground(Color.MAGENTA);
			}
		}
	}

	static String getGanhador() {
		return winner;
	}

	static void desabilitarAberturaCampos() {
		tabuleiro.forEach(b -> {
			if (!b.ocupado) {
				b.ocupado = true;
			}
		});
		camposDesabilitados = true;
	}

	static void animacaoJogadaVencedora() throws Exception {
		new Thread(() -> {
			try {
				final Color VERMELHO = Color.red;
				final Color AMARELO = Color.yellow;
				final Color AZUL = Color.blue;

				tabuleiro.get(jogadaVencedora[0]).setBorder(BorderFactory.createBevelBorder(0));
				tabuleiro.get(jogadaVencedora[1]).setBorder(BorderFactory.createBevelBorder(0));
				tabuleiro.get(jogadaVencedora[2]).setBorder(BorderFactory.createBevelBorder(0));

				tabuleiro.get(jogadaVencedora[0]).setBackground(VERMELHO);
				tabuleiro.get(jogadaVencedora[1]).setBackground(AMARELO);
				tabuleiro.get(jogadaVencedora[2]).setBackground(AZUL);
			} catch (Exception e) {

			}
		}).start();

	}

	static void reiniciar() {
		tabuleiro.forEach(b -> {
			b.setText("");
			b.setBackground(new Color(184, 184, 184));
			b.setBorder(BorderFactory.createBevelBorder(0));
			b.setOpaque(true);
			b.setFont(new Font("Arial", Font.PLAIN, 45));
			b.ocupado = false;
		});

		winner = null;
		camposDesabilitados = false;
		TelaAuxiliar.atualizarTexto();
	}

}
