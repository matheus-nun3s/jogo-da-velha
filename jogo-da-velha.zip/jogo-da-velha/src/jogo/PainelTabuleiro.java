package jogo;

import java.awt.GridLayout;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class PainelTabuleiro extends JPanel {

	final Tabuleiro tabuleiro;

	PainelTabuleiro(Tabuleiro tabuleiro) {
		this.tabuleiro = tabuleiro;
		setLayout(new GridLayout(3, 3));
		for (int i = 0; i < 9; i++) {
			BotaoTabuleiro botao = new BotaoTabuleiro();
			add(botao);
			Tabuleiro.tabuleiro.add(botao);
		}
		setVisible(true);
	}

}
