package jogo;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

@SuppressWarnings("serial")
public class MainFrame extends JFrame {

	final TelaAuxiliar telaAuxiliar;

	MainFrame() {
		telaAuxiliar = new TelaAuxiliar();
		add(BorderLayout.NORTH, TelaAuxiliar.label);
		add(BorderLayout.CENTER, new PainelTabuleiro(new Tabuleiro()));
		SwingUtilities.invokeLater(() -> {
			TelaAuxiliar.atualizarTexto();
			setUndecorated(true);
			getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.gray));
			setSize(200, 225);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setLocation(600, 250);
			setVisible(true);
		});

	}
}
