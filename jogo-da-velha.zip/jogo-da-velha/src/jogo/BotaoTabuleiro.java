 package jogo;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.FileInputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import javazoom.jl.player.Player;

@SuppressWarnings("serial")
public class BotaoTabuleiro extends JButton implements MouseListener {

	boolean ocupado = false;

	BotaoTabuleiro() {
		setBackground(new Color(184, 184, 184));
		setBorder(BorderFactory.createBevelBorder(0));
		setOpaque(true);
		setFont(new Font("Arial", Font.PLAIN, 45));
		addMouseListener(this);
		setVisible(true);
	}

	@Override
	public void mouseClicked(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (!Tabuleiro.camposDesabilitados) {
			switch (e.getButton()) {
			case 1:
				if (Jogo.contadorJogadas % 2 == 1 || this.ocupado) {
					reproduzirSomNegacao();
				} else {
					reproduzirSomClique();
					this.ocupado = true;
					setBorder(BorderFactory.createLineBorder(Color.GRAY));
					setForeground(Color.BLACK);
					setText("X");
					Jogo.contadorJogadas++;
				}
				break; 
			default:
				if (Jogo.contadorJogadas % 2 == 0 || this.ocupado) {
					reproduzirSomNegacao();
				} else {
					reproduzirSomClique();
					this.ocupado = true;
					setBorder(BorderFactory.createLineBorder(Color.GRAY));
					setForeground(Color.WHITE);
					setText("O");
					Jogo.contadorJogadas++;
				}
			}
			TelaAuxiliar.atualizarTexto();
			if (Tabuleiro.temGanhador()) {
				reproduzirSomGanhou();
				Tabuleiro.desabilitarAberturaCampos();
				try {
					SwingUtilities.invokeLater(() -> {
						try {
							Tabuleiro.animacaoJogadaVencedora();
						} catch (Exception ex) {
						}
					});
				} catch (Exception e1) {
					e1.printStackTrace();
				}

				SwingUtilities.invokeLater(() -> {
					boolean reiniciar = JOptionPane.showConfirmDialog(null,
							"Você deseja jogar novamente?\n  (Caso queira visualizar a jogada vencedora, clique na parte superior desta telinha e arraste-a)",
							Tabuleiro.temGanhador() ? Tabuleiro.getGanhador() + ", parabéns! :)" : "VELHAA!! :0",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION ? true
									: false;
					if (reiniciar) {
						Tabuleiro.reiniciar();
					} else {
						System.exit(0);
					}
				});
			} else if (Tabuleiro.tabuleiroPreenchido()) {
				reproduzirSomTabuleiroPreenchido();
				Tabuleiro.desabilitarAberturaCampos();
				TelaAuxiliar.atualizarTexto("  Ops...Deu velha! :(");

				SwingUtilities.invokeLater(() -> {
					Tabuleiro.animacaoTabuleiroPreenchido();
				});

				SwingUtilities.invokeLater(() -> {

					boolean reiniciar = JOptionPane.showConfirmDialog(null, "Você deseja jogar novamente?",
							Tabuleiro.temGanhador() ? Tabuleiro.getGanhador() + ", parabéns! :)" : "VELHAA!! :0",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION ? true
									: false;
					if (reiniciar) {
						Tabuleiro.reiniciar();
					} else {
						System.exit(0);
					}
				});

			}
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	private void reproduzirSomClique() {
		Runnable somClique = () -> {
			try {
				new Player(new FileInputStream("bubble_sound.mp3")).play();
			} catch (Exception e) {
			}
		};

		new Thread(somClique).start();
	}

	private void reproduzirSomNegacao() {
		Runnable somNegacao = () -> {
			try {
				new Player(new FileInputStream("no_sound.mp3")).play();
			} catch (Exception e) {
			}
		};

		new Thread(somNegacao).start();
	}

	private void reproduzirSomGanhou() {
		Runnable somGanhou = () -> {
			try {
				new Player(new FileInputStream("you_win.mp3")).play();
			} catch (Exception e) {
			}
		};

		new Thread(somGanhou).start();
	}

	private void reproduzirSomTabuleiroPreenchido() {
		Runnable somTabuleiroPrenchido = () -> {
			try {
				new Player(new FileInputStream("deu_velha.mp3")).play();
			} catch (Exception e) {

			}
		};

		new Thread(somTabuleiroPrenchido).start();
	}

}
